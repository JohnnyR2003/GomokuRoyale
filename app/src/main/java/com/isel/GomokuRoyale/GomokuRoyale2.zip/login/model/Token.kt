package com.isel.GomokuRoyale.login.model

data class Token(val token: String)