

package com.isel.GomokuRoyale

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import android.app.Application
import android.content.Context
import android.service.autofill.FieldClassification
import android.util.Log
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.isel.GomokuRoyale.lobby.domain.Lobby
import com.isel.GomokuRoyale.lobby.model.LobbyService
//import com.isel.GomokuRoyale.login.UserInfoSharedPrefs
import com.isel.GomokuRoyale.login.model.FakeLoginService
import com.isel.GomokuRoyale.login.model.LoginService
import com.isel.GomokuRoyale.login.model.UserInfoDataStore
import com.isel.GomokuRoyale.login.model.UserInfoRepository
import okhttp3.OkHttpClient
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.LocalCacheSettings
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.isel.GomokuRoyale.lobby.adapters.LobbyFirebase
import com.isel.GomokuRoyale.login.UserInfoSharedPrefs

const val TAG = "GomokuApp"

interface DependenciesContainer {

    val loginService : LoginService

    val userInfoRepo : UserInfoRepository
    val lobby: Lobby
    //val match:

}


class GomokuApplication:Application(), DependenciesContainer{

    private val emulatedFirestoreDb: FirebaseFirestore by lazy {
        Firebase.firestore.also {
            it.useEmulator("10.0.2.2", 8080)
            it.firestoreSettings = FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(false)
                .build()
        }
    }

    private val realFirestoreDb: FirebaseFirestore by lazy {
        Firebase.firestore
    }

    override val lobby: Lobby
        get() = LobbyFirebase(realFirestoreDb)

    override val loginService: LoginService
        get() = FakeLoginService()

    override val userInfoRepo: UserInfoRepository
        get() = UserInfoSharedPrefs(this)


}

