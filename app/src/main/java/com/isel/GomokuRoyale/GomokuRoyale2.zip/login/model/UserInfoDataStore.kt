package com.isel.GomokuRoyale.login.model
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

class UserInfoDataStore(private val store: DataStore<Preferences>) : UserInfoRepository {

    private val userkey = stringPreferencesKey("username")
    private val passkey = stringPreferencesKey("password")
    override var userInfo: UserInfo? = null
        get() = UserInfo(userkey.toString(), passkey.toString())
    /*
    override suspend fun getUserInfo(): UserInfo? {
        val preferences = store.data.first()
        val username = preferences[userkey]
        return if (username != null) preferences[passkey]?.let { UserInfo(username, it) } else null
    }

    override suspend fun updateUserInfo(userInfo: UserInfo?) {
        store.edit { preferences ->
            preferences[userkey] = userInfo!!.username
            userInfo.bearer?.let {
                preferences[passkey] = it
            } ?: preferences.remove(passkey)
        }
    }
  */
}