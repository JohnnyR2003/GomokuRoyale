package com.isel.GomokuRoyale.ui

import androidx.compose.ui.semantics.SemanticsPropertyKey

val IsReadOnly: SemanticsPropertyKey<Unit> = SemanticsPropertyKey("ReadOnly")