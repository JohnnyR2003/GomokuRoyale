package com.isel.GomokuRoyale.login.model

import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.isel.GomokuRoyale.DependenciesContainer
import com.isel.GomokuRoyale.MainScreenViewModel
import com.isel.GomokuRoyale.TAG
import com.isel.GomokuRoyale.about.ui.AboutActivity
import com.isel.GomokuRoyale.home.model.HomeViewModel
import com.isel.GomokuRoyale.login.ui.LoginScreenState
import com.isel.GomokuRoyale.login.ui.LoginView
import com.isel.GomokuRoyale.utils.viewModelInit
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class LoginActivity : ComponentActivity() {

    companion object {
        fun navigateTo(origin: ComponentActivity) {
            val intent = Intent(origin, LoginActivity::class.java)
            origin.startActivity(intent)
        }
    }

    private val repo by lazy {
        (application as DependenciesContainer).userInfoRepo
    }
    private val viewModel: LoginViewModel by viewModels {
        viewModelInit {
            LoginViewModel(
                (application as DependenciesContainer).loginService
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.v(
            TAG,
            "GomokuRoyaleApplication Login Activity.onCreate() on process ${android.os.Process.myPid()}"
        )
        setContent {
            val loadingState by viewModel.isLoading.collectAsState()
            val token by viewModel.token.collectAsState()
            val error by viewModel.error.collectAsState()
            LoginView(
                state = LoginScreenState(token, error,loadingState),
                onSignupRequest = { username, password ->
                    viewModel.fetchRegisterToken(username, password)
                    runBlocking {
                        launch {
                            while (viewModel.isLoading.value);
                            val tok: Token? = viewModel.token.value
                            if (tok != null) {
                                repo.userInfo = UserInfo(username, tok.token)
                                if (repo.userInfo != null)
                                    finish()
                            }
                        }
                    }
                    viewModel.resetError()
                },
                onSignInRequest = { username, password ->
                    viewModel.fetchLoginToken(username, password)
                    runBlocking {
                        launch {
                            while (viewModel.isLoading.value);
                            val tok: Token? = viewModel.token.value
                            if (tok != null) {
                                repo.userInfo = UserInfo(username, tok.token)
                                if (repo.userInfo != null)
                                    finish()
                            }
                        }
                    }
                    viewModel.resetError()
                },
                onBackRequest = {
                    finish()
                }
            )
        }
    }
}