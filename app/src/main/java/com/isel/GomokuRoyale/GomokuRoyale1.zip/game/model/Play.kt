package com.isel.GomokuRoyale.game.model

data class GameDTO(
    val uuid: String,
    val state: String,
    val nextPlay: String,
    val player1: String,
    val player2: String,
    val board: String,
    val moves1: String,
    val moves2: String,
    val variant: Int,
    val result: Int,
)

data class Lounge(val uuid: String, val player1: String, val variant: Int)

fun variantToString(variant: Int): String {
    return when (variant) {
        1 -> "15x15"
        2 -> "19x19"
        else -> "Unavailable"
    }
}