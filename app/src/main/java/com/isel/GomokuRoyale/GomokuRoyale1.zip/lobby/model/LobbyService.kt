package com.isel.GomokuRoyale.lobby.model

import com.isel.GomokuRoyale.game.model.Lounge
import com.isel.GomokuRoyale.login.model.UserInfo

interface LobbyService {

    suspend fun getRooms(): List<Lounge>

    suspend fun joinMatch(gameId: String): String

    suspend fun createMatch(spr: Int): String

}

class FakeLobbyService(private val userInfo: UserInfo): LobbyService{

    var rooms :List<Lounge> = listOf(
        Lounge("fake", userInfo.username, 1),
        Lounge("fake2", userInfo.username, 1),
        Lounge("fake3", userInfo.username, 1),
        Lounge("fake4", userInfo.username, 1),
        Lounge("fake5", userInfo.username, 1),
        Lounge("fake6", userInfo.username, 1),
    )

    override suspend fun getRooms(): List<Lounge> {
        return rooms
    }

    override suspend fun joinMatch(gameId: String): String {
        val match = rooms.filter { it.uuid == gameId }[0].uuid
        if (match == null) return "No match found"
        else return "Joined match $match"
    }

    override suspend fun createMatch(variant: Int): String {
       rooms = rooms + Lounge("test", userInfo.username, variant)
        return "Match created successfully"
    }

}