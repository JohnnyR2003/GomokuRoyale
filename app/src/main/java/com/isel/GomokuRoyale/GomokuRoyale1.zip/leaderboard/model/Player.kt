package com.isel.GomokuRoyale.leaderboard.model

data class PlayerInfo(val username: String, val games: Int, val points: Int)