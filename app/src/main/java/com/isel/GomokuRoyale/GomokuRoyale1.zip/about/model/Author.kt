package com.isel.GomokuRoyale.about.model

data class Author(val name:String, val email:String, val github:String)