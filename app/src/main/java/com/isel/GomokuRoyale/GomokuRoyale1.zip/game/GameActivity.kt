package com.isel.GomokuRoyale.game

import android.app.appsearch.SearchResult
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.annotation.RequiresApi
import com.isel.GomokuRoyale.lobby.domain.PlayerInfo
import com.isel.GomokuRoyale.lobby.ui.LobbyActivity
import okhttp3.Challenge


class GameActivity : ComponentActivity() {

   /*
    companion object {
        const val MATCH_INFO_EXTRA = "MATCH_INFO_EXTRA"

        @RequiresApi(Build.VERSION_CODES.S)
        fun navigate(origin: Context, localPlayer: PlayerInfo, challenge: Challenge) {
            with(origin) {
                startActivity(
                    Intent(this, GameActivity::class.java).also {
                        it.putExtra(
                            MATCH_INFO_EXTRA, SearchResult.MatchInfo(localPlayer, challenge)
                        )
                    }
                )
            }
        }
    }
    internal fun MatchInfo(localPlayer: PlayerInfo, challenge: Challenge): SearchResult.MatchInfo {
        val opponent =
            if (localPlayer == challenge.challenged) challenge.challenger
            else challenge.challenged

        return MatchInfo(
            localPlayerId = localPlayer.id.toString(),
            localPlayerNick = localPlayer.info.nick,
            opponentId = opponent.id.toString(),
            opponentNick = opponent.info.nick,
            challengerId = challenge.challenger.id.toString(),
        )
    }*/
}